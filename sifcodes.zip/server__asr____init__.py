"""ASR engine package: abstraction + Whisper/Vosk implementations."""
from __future__ import annotations

from config import AsrEngineType, Settings
from .base import AsrEngine, AsrEngineError, TranscriptionResult
from .whisper_engine import WhisperAsrEngine
from .vosk_engine import VoskAsrEngine

__all__ = [
    "AsrEngine",
    "AsrEngineError",
    "TranscriptionResult",
    "create_asr_engine",
]


def create_asr_engine(settings: Settings) -> AsrEngine:
    """Factory: instantiates the ASR engine selected in Settings."""
    if settings.asr_engine == AsrEngineType.WHISPER:
        return WhisperAsrEngine(model_size=settings.whisper_model_size)
    if settings.asr_engine == AsrEngineType.VOSK:
        return VoskAsrEngine(model_path=settings.vosk_model_path)
    raise ValueError(f"Unknown ASR engine: {settings.asr_engine}")
