"""
Train the VYOM-EDGE compact DS-CNN keyword spotting model.

Feature extraction (MFCC) mirrors firmware/main/mfcc.h/.cpp parameters so
the trained model's expected input distribution matches what the ESP32-S3
will produce at inference time:
    - 16kHz mono audio
    - 30ms frame length / 20ms hop -> ~49 frames per 1s clip
    - 40 mel bins, 10 MFCC coefficients kept
"""
from __future__ import annotations

import argparse
import logging
from pathlib import Path

import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models

from augment import augment_batch

logger = logging.getLogger("vyom.train_kws")

SAMPLE_RATE = 16000
FRAME_LEN_MS = 30
FRAME_STEP_MS = 20
NUM_MEL_BINS = 40
NUM_MFCC = 10
NUM_FRAMES = 49  # matches kNumFramesWindow in firmware/main/mfcc.h
NUM_CLASSES = 3  # silence, unknown, wakeword


def waveform_to_mfcc(waveform: np.ndarray) -> np.ndarray:
    """
    Computes an MFCC feature matrix [NUM_FRAMES, NUM_MFCC] using
    tf.signal, matching the firmware's frame/hop/mel-bin configuration.
    """
    frame_length = int(SAMPLE_RATE * FRAME_LEN_MS / 1000)
    frame_step = int(SAMPLE_RATE * FRAME_STEP_MS / 1000)

    wav = tf.cast(waveform, tf.float32) / 32768.0
    stft = tf.signal.stft(wav, frame_length=frame_length, frame_step=frame_step,
                           fft_length=512, window_fn=tf.signal.hamming_window)
    spectrogram = tf.abs(stft)

    num_spectrogram_bins = spectrogram.shape[-1]
    mel_weight_matrix = tf.signal.linear_to_mel_weight_matrix(
        num_mel_bins=NUM_MEL_BINS, num_spectrogram_bins=num_spectrogram_bins,
        sample_rate=SAMPLE_RATE, lower_edge_hertz=0.0, upper_edge_hertz=SAMPLE_RATE / 2.0,
    )
    mel_spectrogram = tf.tensordot(spectrogram, mel_weight_matrix, 1)
    log_mel = tf.math.log(mel_spectrogram + 1e-6)

    mfccs = tf.signal.mfccs_from_log_mel_spectrograms(log_mel)[..., :NUM_MFCC]

    mfccs = mfccs.numpy()
    if mfccs.shape[0] < NUM_FRAMES:
        pad = np.zeros((NUM_FRAMES - mfccs.shape[0], NUM_MFCC), dtype=np.float32)
        mfccs = np.concatenate([mfccs, pad], axis=0)
    else:
        mfccs = mfccs[:NUM_FRAMES]
    return mfccs.astype(np.float32)


def build_ds_cnn(input_shape: tuple[int, int, int] = (NUM_FRAMES, NUM_MFCC, 1),
                  num_classes: int = NUM_CLASSES) -> tf.keras.Model:
    """
    Compact depthwise-separable CNN, sized to keep the INT8 model well
    within the <256KB RAM / small flash budget targeted for the ESP32-S3.
    Architecture follows the "Hello Edge" DS-CNN family (Zhang et al.,
    2017) referenced in the project's research list.
    """
    inputs = layers.Input(shape=input_shape)

    x = layers.Conv2D(64, (10, 4), strides=(2, 2), padding="same", activation="relu")(inputs)
    x = layers.BatchNormalization()(x)

    for filters in (64, 64, 64):
        x = layers.DepthwiseConv2D((3, 3), padding="same", activation="relu")(x)
        x = layers.BatchNormalization()(x)
        x = layers.Conv2D(filters, (1, 1), padding="same", activation="relu")(x)
        x = layers.BatchNormalization()(x)

    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dropout(0.3)(x)
    outputs = layers.Dense(num_classes, activation="softmax")(x)

    return models.Model(inputs, outputs, name="vyom_ds_cnn_kws")


def prepare_features(x_wave: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    logger.info("Extracting MFCC features for %d clips...", len(x_wave))
    features = np.stack([waveform_to_mfcc(clip) for clip in x_wave])
    features = features[..., np.newaxis]  # add channel dim
    return features.astype(np.float32), y.astype(np.int64)


def load_split(data_dir: Path, split: str) -> tuple[np.ndarray, np.ndarray]:
    x = np.load(data_dir / f"{split}_x.npy")
    y = np.load(data_dir / f"{split}_y.npy")
    return x, y


def load_background_noises(root: Path) -> list[np.ndarray]:
    import soundfile as sf

    noise_dir = root / "_background_noise_"
    noises = []
    if noise_dir.exists():
        for f in sorted(noise_dir.glob("*.wav")):
            audio, _ = sf.read(str(f), dtype="int16")
            noises.append(audio if audio.ndim == 1 else audio[:, 0])
    return noises


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")
    parser = argparse.ArgumentParser(description="Train VYOM-EDGE KWS model")
    parser.add_argument("--data-dir", type=Path, default=Path("data/prepared"))
    parser.add_argument("--raw-dataset-root", type=Path, default=None,
                         help="Original dataset root, needed for noise augmentation")
    parser.add_argument("--epochs", type=int, default=40)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--augment-multiplier", type=int, default=2)
    parser.add_argument("--out", type=Path, default=Path("models/kws_float.keras"))
    args = parser.parse_args()

    x_train, y_train = load_split(args.data_dir, "train")
    x_val, y_val = load_split(args.data_dir, "val")

    if args.augment_multiplier > 0:
        noises = load_background_noises(args.raw_dataset_root) if args.raw_dataset_root else []
        x_train, y_train = augment_batch(x_train, y_train, noises, multiplier=args.augment_multiplier)
        logger.info("Augmented training set to %d clips", len(x_train))

    feat_train, y_train = prepare_features(x_train, y_train)
    feat_val, y_val = prepare_features(x_val, y_val)

    model = build_ds_cnn()
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    model.summary(print_fn=logger.info)

    callbacks = [
        tf.keras.callbacks.EarlyStopping(monitor="val_accuracy", patience=8, restore_best_weights=True),
        tf.keras.callbacks.ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=4),
    ]

    model.fit(
        feat_train, y_train,
        validation_data=(feat_val, y_val),
        epochs=args.epochs,
        batch_size=args.batch_size,
        callbacks=callbacks,
    )

    args.out.parent.mkdir(parents=True, exist_ok=True)
    model.save(args.out)
    logger.info("Saved trained float model to %s", args.out)


if __name__ == "__main__":
    main()
