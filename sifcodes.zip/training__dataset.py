"""
Dataset preparation for VYOM-EDGE keyword spotting training.

Expects a directory layout like Google's Speech Commands dataset, plus a
custom wake-word class:

    dataset/
        wakeword/         *.wav  (your custom wake word, e.g. "vyom")
        _background_noise_/ *.wav
        <other classes>/  *.wav  (used as "unknown" negatives)

Produces fixed-length (1s @ 16kHz) labeled clips as numpy arrays, split
into train/val/test.
"""
from __future__ import annotations

import argparse
import json
import logging
import random
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import soundfile as sf

logger = logging.getLogger("vyom.dataset")

SAMPLE_RATE = 16000
CLIP_SECONDS = 1.0
CLIP_LEN = int(SAMPLE_RATE * CLIP_SECONDS)

LABEL_SILENCE = 0
LABEL_UNKNOWN = 1
LABEL_WAKEWORD = 2


@dataclass
class DatasetConfig:
    root_dir: Path
    wakeword_dir: str = "wakeword"
    background_dir: str = "_background_noise_"
    unknown_ratio: float = 2.0     # unknown clips per wake-word clip
    silence_ratio: float = 1.0     # silence clips per wake-word clip
    val_split: float = 0.15
    test_split: float = 0.15
    seed: int = 42


def load_and_pad(path: Path) -> np.ndarray:
    audio, sr = sf.read(str(path), dtype="int16")
    if sr != SAMPLE_RATE:
        raise ValueError(f"{path} has sample rate {sr}, expected {SAMPLE_RATE}. Resample first.")
    if audio.ndim > 1:
        audio = audio[:, 0]
    if len(audio) >= CLIP_LEN:
        # Center-crop for deterministic behavior; augment.py handles
        # random cropping during training-time augmentation.
        start = max(0, (len(audio) - CLIP_LEN) // 2)
        return audio[start:start + CLIP_LEN]
    padded = np.zeros(CLIP_LEN, dtype=np.int16)
    padded[: len(audio)] = audio
    return padded


def make_silence_clips(background_files: list[Path], count: int, rng: random.Random) -> list[np.ndarray]:
    clips = []
    if not background_files:
        logger.warning("No background noise files found; generating low-amplitude white noise instead")
        for _ in range(count):
            clips.append((rng.gauss(0, 1) * np.random.randn(CLIP_LEN) * 50).astype(np.int16))
        return clips

    for _ in range(count):
        path = rng.choice(background_files)
        audio, sr = sf.read(str(path), dtype="int16")
        if audio.ndim > 1:
            audio = audio[:, 0]
        if len(audio) <= CLIP_LEN:
            clip = np.zeros(CLIP_LEN, dtype=np.int16)
            clip[: len(audio)] = audio
        else:
            start = rng.randint(0, len(audio) - CLIP_LEN)
            clip = audio[start:start + CLIP_LEN]
        clips.append(clip)
    return clips


def collect_class_files(root: Path, wakeword_dir: str, background_dir: str) -> tuple[list[Path], list[Path], list[Path]]:
    wakeword_files = sorted((root / wakeword_dir).glob("*.wav"))
    background_files = sorted((root / background_dir).glob("*.wav")) if (root / background_dir).exists() else []

    unknown_files: list[Path] = []
    for d in sorted(root.iterdir()):
        if not d.is_dir() or d.name in (wakeword_dir, background_dir):
            continue
        unknown_files.extend(d.glob("*.wav"))

    return wakeword_files, unknown_files, background_files


def build_dataset(cfg: DatasetConfig) -> dict[str, list[tuple[np.ndarray, int]]]:
    rng = random.Random(cfg.seed)
    wakeword_files, unknown_files, background_files = collect_class_files(
        cfg.root_dir, cfg.wakeword_dir, cfg.background_dir
    )
    logger.info("Found %d wake-word, %d unknown, %d background files",
                len(wakeword_files), len(unknown_files), len(background_files))

    if not wakeword_files:
        raise RuntimeError(f"No wake-word .wav files found under {cfg.root_dir / cfg.wakeword_dir}")

    n_wake = len(wakeword_files)
    n_unknown = min(len(unknown_files), int(n_wake * cfg.unknown_ratio)) or len(unknown_files)
    n_silence = int(n_wake * cfg.silence_ratio)

    samples: list[tuple[np.ndarray, int]] = []
    for f in wakeword_files:
        samples.append((load_and_pad(f), LABEL_WAKEWORD))

    chosen_unknown = rng.sample(unknown_files, n_unknown) if unknown_files else []
    for f in chosen_unknown:
        samples.append((load_and_pad(f), LABEL_UNKNOWN))

    for clip in make_silence_clips(background_files, n_silence, rng):
        samples.append((clip, LABEL_SILENCE))

    rng.shuffle(samples)

    n = len(samples)
    n_val = int(n * cfg.val_split)
    n_test = int(n * cfg.test_split)
    n_train = n - n_val - n_test

    return {
        "train": samples[:n_train],
        "val": samples[n_train:n_train + n_val],
        "test": samples[n_train + n_val:],
    }


def save_split(split_name: str, samples: list[tuple[np.ndarray, int]], out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    x = np.stack([s[0] for s in samples]).astype(np.int16)
    y = np.array([s[1] for s in samples], dtype=np.int64)
    np.save(out_dir / f"{split_name}_x.npy", x)
    np.save(out_dir / f"{split_name}_y.npy", y)
    logger.info("Saved %s: %d samples -> %s", split_name, len(samples), out_dir)


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")
    parser = argparse.ArgumentParser(description="Prepare KWS dataset for VYOM-EDGE")
    parser.add_argument("--root", type=Path, required=True, help="Dataset root directory")
    parser.add_argument("--out", type=Path, default=Path("data/prepared"))
    parser.add_argument("--unknown-ratio", type=float, default=2.0)
    parser.add_argument("--silence-ratio", type=float, default=1.0)
    args = parser.parse_args()

    cfg = DatasetConfig(
        root_dir=args.root,
        unknown_ratio=args.unknown_ratio,
        silence_ratio=args.silence_ratio,
    )
    splits = build_dataset(cfg)
    for name, samples in splits.items():
        save_split(name, samples, args.out)

    meta = {"labels": {"silence": LABEL_SILENCE, "unknown": LABEL_UNKNOWN, "wakeword": LABEL_WAKEWORD},
            "sample_rate": SAMPLE_RATE, "clip_len": CLIP_LEN}
    (args.out / "meta.json").write_text(json.dumps(meta, indent=2))


if __name__ == "__main__":
    main()
