"""
Benchmarking utilities for the VYOM-EDGE stack:
  - ASR engine transcription latency (server-side)
  - WebSocket end-to-end round-trip time
  - TFLite KWS model size / inference latency (host-side sanity check;
    the authoritative on-device latency comes from firmware/main/metrics.cpp)

Run with: python tests/benchmark.py --help
"""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import statistics
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "server"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "training"))

logger = logging.getLogger("vyom.benchmark")


async def benchmark_asr_engine(engine_name: str, num_runs: int, duration_s: float) -> None:
    from asr import create_asr_engine
    from config import Settings, AsrEngineType

    settings = Settings()
    settings.asr_engine = AsrEngineType(engine_name)
    engine = create_asr_engine(settings)

    logger.info("Loading %s engine...", engine_name)
    await engine.load()

    sample_rate = settings.sample_rate_hz
    n_samples = int(duration_s * sample_rate)
    t = np.arange(n_samples) / sample_rate
    pcm = (np.sin(2 * np.pi * 200 * t) * 8000).astype(np.int16).tobytes()

    latencies = []
    for i in range(num_runs):
        result = await engine.transcribe_pcm16(pcm, sample_rate)
        latencies.append(result.latency_ms)
        logger.info("Run %d/%d: %.1fms -> '%s'", i + 1, num_runs, result.latency_ms, result.text)

    logger.info("---- %s benchmark (%d runs, %.1fs clips) ----", engine_name, num_runs, duration_s)
    logger.info("mean=%.1fms  p50=%.1fms  p95=%.1fms  max=%.1fms",
                statistics.mean(latencies),
                statistics.median(latencies),
                np.percentile(latencies, 95),
                max(latencies))


def benchmark_tflite_model(model_path: Path, num_runs: int) -> None:
    import tensorflow as tf

    interpreter = tf.lite.Interpreter(model_path=str(model_path))
    interpreter.allocate_tensors()
    input_details = interpreter.get_input_details()[0]
    output_details = interpreter.get_output_details()[0]

    shape = input_details["shape"]
    dtype = input_details["dtype"]
    dummy_input = np.random.randint(-128, 127, size=shape).astype(dtype)

    # Warmup
    for _ in range(5):
        interpreter.set_tensor(input_details["index"], dummy_input)
        interpreter.invoke()

    latencies = []
    for _ in range(num_runs):
        start = time.perf_counter()
        interpreter.set_tensor(input_details["index"], dummy_input)
        interpreter.invoke()
        _ = interpreter.get_tensor(output_details["index"])
        latencies.append((time.perf_counter() - start) * 1000)

    model_size_kb = model_path.stat().st_size / 1024
    logger.info("---- TFLite KWS model benchmark (host CPU, not representative of ESP32-S3) ----")
    logger.info("Model size: %.1f KB", model_size_kb)
    logger.info("Host inference: mean=%.3fms  p95=%.3fms  (n=%d)",
                statistics.mean(latencies), np.percentile(latencies, 95), num_runs)
    logger.info("NOTE: on-device latency/CPU/RAM must be read from the ESP32-S3 "
                "serial metrics output (firmware/main/metrics.cpp), not this host benchmark.")


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")
    parser = argparse.ArgumentParser(description="VYOM-EDGE benchmarking")
    sub = parser.add_subparsers(dest="command", required=True)

    asr_parser = sub.add_parser("asr", help="Benchmark an ASR engine")
    asr_parser.add_argument("--engine", choices=["whisper", "vosk"], default="whisper")
    asr_parser.add_argument("--runs", type=int, default=5)
    asr_parser.add_argument("--duration", type=float, default=2.0)

    tflite_parser = sub.add_parser("kws", help="Benchmark a TFLite KWS model")
    tflite_parser.add_argument("--model", type=Path, default=Path("../training/models/kws_int8.tflite"))
    tflite_parser.add_argument("--runs", type=int, default=100)

    args = parser.parse_args()

    if args.command == "asr":
        asyncio.run(benchmark_asr_engine(args.engine, args.runs, args.duration))
    elif args.command == "kws":
        benchmark_tflite_model(args.model, args.runs)


if __name__ == "__main__":
    main()
