#pragma once
// VYOM-EDGE Firmware
// Dual INMP441 I2S microphone capture + lock-free ring buffer
// C++ / ESP-IDF

#include <cstdint>
#include <cstddef>
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "driver/i2s_std.h"
#include "esp_err.h"

namespace vyom {

// ---- Configuration ----
constexpr uint32_t kSampleRateHz      = 16000;
constexpr uint32_t kI2SBitsPerSample  = 32;   // INMP441 outputs 24-bit in a 32-bit slot
constexpr uint32_t kI2SDmaBufCount    = 6;
constexpr uint32_t kI2SDmaFrameLen    = 512;  // frames per DMA buffer
constexpr uint32_t kRingBufferFrames  = kSampleRateHz * 4; // 4 seconds of audio @16kHz

// Pin mapping - adjust to board wiring
struct I2SPinConfig {
    int bck_io_num  = 4;
    int ws_io_num   = 5;
    int data_in_num = 6;   // shared data line, mic L/R select via WS
};

// Single-producer / single-consumer ring buffer of mono int16 PCM samples.
// Producer: I2S capture task. Consumer: MFCC / KWS task.
class AudioRingBuffer {
public:
    explicit AudioRingBuffer(size_t capacity_frames = kRingBufferFrames);
    ~AudioRingBuffer();

    // Writes `count` mono int16 samples. Overwrites oldest data if full
    // (keeps latency bounded, matches "streaming" KWS semantics).
    void Write(const int16_t* samples, size_t count);

    // Reads up to `count` samples into `out`. Returns number of samples read.
    size_t Read(int16_t* out, size_t count);

    // Non-destructive peek of the most recent `count` samples (used for the
    // pre-trigger buffer snapshot on wake-word detection).
    size_t PeekLatest(int16_t* out, size_t count) const;

    size_t Available() const;
    size_t Capacity() const { return capacity_; }

private:
    int16_t* buf_;
    size_t capacity_;
    volatile size_t write_idx_ = 0;
    volatile size_t read_idx_  = 0;
    volatile size_t count_     = 0;
    mutable SemaphoreHandle_t mutex_;
};

class AudioCapture {
public:
    AudioCapture(AudioRingBuffer& ring_buffer, const I2SPinConfig& pins = I2SPinConfig());

    // Initializes the I2S peripheral in standard (Philips) mode, stereo,
    // and averages/selects the left channel (mic 0) while mic 1 (right
    // channel) is available for future beamforming/dual-mic use.
    esp_err_t Init();

    // Blocking read+downmix+push into ring buffer. Meant to be called in a
    // tight loop from a dedicated FreeRTOS task (see main.cpp).
    esp_err_t CaptureOnce();

    // Returns raw dual-channel frame count captured since boot (for metrics).
    uint64_t TotalFramesCaptured() const { return total_frames_; }

private:
    AudioRingBuffer& ring_;
    I2SPinConfig pins_;
    i2s_chan_handle_t rx_handle_ = nullptr;
    int32_t dma_raw_[kI2SDmaFrameLen * 2]; // stereo, 32-bit slots
    int16_t mono_scratch_[kI2SDmaFrameLen];
    uint64_t total_frames_ = 0;
};

} // namespace vyom
