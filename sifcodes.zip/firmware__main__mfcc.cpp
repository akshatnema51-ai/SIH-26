#include "mfcc.h"
#include <cmath>
#include <cstring>
#include <algorithm>

namespace vyom {

namespace {
// Minimal in-place radix-2 FFT (real input, magnitude output only).
// Sized for kFftSize (power of two). This avoids pulling in a large FFT
// dependency; ESP-DSP's optimized FFT can be swapped in via
// CONFIG_VYOM_USE_ESP_DSP for production builds.
void RealFFTMagnitude(const float* in, int n, float* out_mag, int out_len) {
    static std::array<float, kFftSize> re;
    static std::array<float, kFftSize> im;
    for (int i = 0; i < n; ++i) { re[i] = in[i]; im[i] = 0.0f; }
    for (int i = n; i < kFftSize; ++i) { re[i] = 0.0f; im[i] = 0.0f; }

    // Bit-reversal permutation
    int j = 0;
    for (int i = 0; i < kFftSize - 1; ++i) {
        if (i < j) { std::swap(re[i], re[j]); std::swap(im[i], im[j]); }
        int k = kFftSize >> 1;
        while (k <= j) { j -= k; k >>= 1; }
        j += k;
    }

    for (int len = 2; len <= kFftSize; len <<= 1) {
        float ang = -2.0f * (float)M_PI / len;
        float wr = cosf(ang), wi = sinf(ang);
        for (int i = 0; i < kFftSize; i += len) {
            float cwr = 1.0f, cwi = 0.0f;
            for (int k = 0; k < len / 2; ++k) {
                float ur = re[i + k], ui = im[i + k];
                float vr = re[i + k + len / 2] * cwr - im[i + k + len / 2] * cwi;
                float vi = re[i + k + len / 2] * cwi + im[i + k + len / 2] * cwr;
                re[i + k] = ur + vr;
                im[i + k] = ui + vi;
                re[i + k + len / 2] = ur - vr;
                im[i + k + len / 2] = ui - vi;
                float ncwr = cwr * wr - cwi * wi;
                float ncwi = cwr * wi + cwi * wr;
                cwr = ncwr; cwi = ncwi;
            }
        }
    }
    for (int i = 0; i < out_len; ++i) {
        out_mag[i] = sqrtf(re[i] * re[i] + im[i] * im[i]);
    }
}

float HzToMel(float hz) { return 2595.0f * log10f(1.0f + hz / 700.0f); }
float MelToHz(float mel) { return 700.0f * (powf(10.0f, mel / 2595.0f) - 1.0f); }
} // namespace

MfccExtractor::MfccExtractor() {
    BuildHammingWindow();
    BuildMelFilterbank();
}

void MfccExtractor::BuildHammingWindow() {
    for (int i = 0; i < kFrameLenSamples; ++i) {
        hamming_window_[i] = 0.54f - 0.46f * cosf(2.0f * (float)M_PI * i / (kFrameLenSamples - 1));
    }
}

void MfccExtractor::BuildMelFilterbank() {
    const int num_fft_bins = kFftSize / 2 + 1;
    const float low_mel = HzToMel(0.0f);
    const float high_mel = HzToMel(kSampleRate / 2.0f);
    std::array<float, kNumMelBins + 2> mel_points{};
    for (int i = 0; i < kNumMelBins + 2; ++i) {
        mel_points[i] = low_mel + (high_mel - low_mel) * i / (kNumMelBins + 1);
    }
    std::array<int, kNumMelBins + 2> bin{};
    for (int i = 0; i < kNumMelBins + 2; ++i) {
        float hz = MelToHz(mel_points[i]);
        bin[i] = (int)floorf((kFftSize + 1) * hz / kSampleRate);
    }
    for (int m = 0; m < kNumMelBins; ++m) {
        for (int k = 0; k < num_fft_bins; ++k) {
            float w = 0.0f;
            if (k >= bin[m] && k <= bin[m + 1] && (bin[m + 1] - bin[m]) > 0) {
                w = (float)(k - bin[m]) / (bin[m + 1] - bin[m]);
            } else if (k >= bin[m + 1] && k <= bin[m + 2] && (bin[m + 2] - bin[m + 1]) > 0) {
                w = (float)(bin[m + 2] - k) / (bin[m + 2] - bin[m + 1]);
            }
            mel_filterbank_[m][k] = w;
        }
    }
}

void MfccExtractor::ApplyHammingWindow(float* samples, int n) const {
    for (int i = 0; i < n; ++i) samples[i] *= hamming_window_[i];
}

void MfccExtractor::ComputeFrame(const float* windowed_samples, MfccFrame& out) {
    const int num_fft_bins = kFftSize / 2 + 1;
    static std::array<float, kFftSize / 2 + 1> mag;
    RealFFTMagnitude(windowed_samples, kFrameLenSamples, mag.data(), num_fft_bins);

    std::array<float, kNumMelBins> mel_energy{};
    for (int m = 0; m < kNumMelBins; ++m) {
        float e = 0.0f;
        for (int k = 0; k < num_fft_bins; ++k) e += mag[k] * mel_filterbank_[m][k];
        mel_energy[m] = logf(std::max(e, 1e-10f));
    }

    // DCT-II to get MFCCs, keep first kNumMfcc coefficients.
    for (int c = 0; c < kNumMfcc; ++c) {
        float sum = 0.0f;
        for (int m = 0; m < kNumMelBins; ++m) {
            sum += mel_energy[m] * cosf((float)M_PI * c * (m + 0.5f) / kNumMelBins);
        }
        out[c] = sum;
    }
}

bool MfccExtractor::PushSamples(const int16_t* hop, size_t hop_len, MfccFrame& out_frame) {
    // Shift history buffer left by hop_len and append the new hop, so the
    // last kFrameLenSamples always contains the current analysis window.
    // This is the "incremental" part: we never recompute FFT over audio
    // already processed in a previous hop, only the newly completed window.
    if (hop_len != (size_t)kFrameStepSamples) return false;

    if (history_filled_ < kFrameLenSamples) {
        // Still filling the very first window.
        int space = kFrameLenSamples - history_filled_;
        int n = std::min((int)hop_len, space);
        memcpy(&sample_history_[history_filled_], hop, n * sizeof(int16_t));
        history_filled_ += n;
        if (history_filled_ < kFrameLenSamples) return false;
    } else {
        int keep = kFrameLenSamples - kFrameStepSamples;
        memmove(sample_history_.data(), sample_history_.data() + kFrameStepSamples,
                keep * sizeof(int16_t));
        memcpy(sample_history_.data() + keep, hop, kFrameStepSamples * sizeof(int16_t));
    }

    static std::array<float, kFrameLenSamples> windowed;
    for (int i = 0; i < kFrameLenSamples; ++i) {
        windowed[i] = sample_history_[i] / 32768.0f;
    }
    ApplyHammingWindow(windowed.data(), kFrameLenSamples);
    ComputeFrame(windowed.data(), out_frame);

    window_[write_pos_] = out_frame;
    write_pos_ = (write_pos_ + 1) % kNumFramesWindow;
    frames_filled_++;
    return true;
}

void MfccExtractor::Reset() {
    history_filled_ = 0;
    write_pos_ = 0;
    frames_filled_ = 0;
    window_.fill(MfccFrame{});
}

} // namespace vyom
