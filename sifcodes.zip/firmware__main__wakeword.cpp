#include "wakeword.h"
#include "esp_log.h"

namespace vyom {

static const char* TAG = "wakeword";

WakeWordDetector::WakeWordDetector(AudioRingBuffer& ring, KwsEngine& kws)
    : ring_(ring), kws_(kws) {}

bool WakeWordDetector::Process() {
    size_t got = ring_.Read(hop_buf_, kFrameStepSamples);
    if (got != kFrameStepSamples) {
        return false; // not enough audio yet this tick
    }

    MfccFrame frame;
    bool have_frame = mfcc_.PushSamples(hop_buf_, kFrameStepSamples, frame);
    if (!have_frame) {
        return false; // still filling the initial analysis window
    }

    last_result_ = kws_.Infer(mfcc_);

    if (suppressed_) {
        return false;
    }

    if (last_result_.triggered) {
        ESP_LOGI(TAG, "Wake word triggered. confidence=%.3f smoothed=%.3f",
                 last_result_.confidence, last_result_.smoothed_confidence);

        size_t n = ring_.PeekLatest(pretrigger_buf_, kPreTriggerSamples);
        if (callback_) {
            callback_(pretrigger_buf_, n, last_result_.smoothed_confidence);
        }
        kws_.ResetSmoothing();
        mfcc_.Reset();
        return true;
    }
    return false;
}

} // namespace vyom
