"""
Tests for the VYOM-EDGE FastAPI/WebSocket backend.

Run with: pytest tests/test_server.py
"""
from __future__ import annotations

import asyncio
import json
import struct
import sys
from pathlib import Path

import numpy as np
import pytest
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "server"))

from asr.base import AsrEngine, TranscriptionResult  # noqa: E402
from config import Settings  # noqa: E402


class FakeAsrEngine(AsrEngine):
    """Deterministic stand-in ASR engine for testing the WebSocket flow
    without loading real Whisper/Vosk models."""

    def __init__(self, fixed_text: str = "turn on the lights"):
        self.fixed_text = fixed_text
        self.loaded = False

    @property
    def name(self) -> str:
        return "fake-asr"

    async def load(self) -> None:
        self.loaded = True

    async def transcribe_pcm16(self, pcm_bytes: bytes, sample_rate: int) -> TranscriptionResult:
        return TranscriptionResult(
            text=self.fixed_text,
            confidence=0.95,
            is_final=True,
            engine=self.name,
            latency_ms=5.0,
        )


def make_silence_pcm16(seconds: float, sample_rate: int = 16000) -> bytes:
    n = int(seconds * sample_rate)
    return struct.pack(f"<{n}h", *([0] * n))


def make_tone_pcm16(seconds: float, sample_rate: int = 16000, freq: float = 440.0) -> bytes:
    n = int(seconds * sample_rate)
    t = np.arange(n) / sample_rate
    samples = (np.sin(2 * np.pi * freq * t) * 10000).astype(np.int16)
    return samples.tobytes()


@pytest.fixture
def app_with_fake_asr(monkeypatch):
    import main as server_main

    fake_engine = FakeAsrEngine()
    monkeypatch.setattr(server_main, "asr_engine", fake_engine)
    return server_main.app, fake_engine


def test_health_endpoint(app_with_fake_asr):
    app, _ = app_with_fake_asr
    client = TestClient(app)
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"


def test_full_utterance_roundtrip(app_with_fake_asr):
    app, fake_engine = app_with_fake_asr
    client = TestClient(app)

    with client.websocket_connect("/ws/audio") as ws:
        ws.send_text(json.dumps({"event": "hello", "device_id": "esp32-test"}))
        ws.send_text(json.dumps({"event": "utterance_start", "confidence": 0.9}))
        ws.send_bytes(make_tone_pcm16(0.6))
        ws.send_text(json.dumps({"event": "utterance_end"}))

        response = json.loads(ws.receive_text())
        assert response["event"] == "transcription"
        assert response["text"] == fake_engine.fixed_text
        assert response["confidence"] == pytest.approx(0.95)


def test_short_utterance_flagged_as_false_trigger(app_with_fake_asr):
    app, _ = app_with_fake_asr
    client = TestClient(app)

    with client.websocket_connect("/ws/audio") as ws:
        ws.send_text(json.dumps({"event": "utterance_start", "confidence": 0.6}))
        ws.send_bytes(make_silence_pcm16(0.1))  # below min_utterance_duration_s
        ws.send_text(json.dumps({"event": "utterance_end"}))

        response = json.loads(ws.receive_text())
        assert response["event"] == "false_trigger"
        assert response["reason"] == "too_short"


def test_settings_defaults():
    settings = Settings()
    assert settings.sample_rate_hz == 16000
    assert settings.channels == 1
    assert settings.min_utterance_duration_s > 0
