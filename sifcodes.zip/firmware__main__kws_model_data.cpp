// Placeholder for the trained INT8 KWS model, embedded as a C array.
//
// Generate the real file with:
//   xxd -i kws_int8.tflite > kws_model_data.cpp
// then rename the generated symbols to g_kws_model_data / g_kws_model_len,
// or use the helper: training/convert_tflite.py --emit-cc-array
//
// This placeholder is an empty/invalid model and MUST be replaced before
// flashing a real device; kws.cpp's Init() will fail schema validation
// against this data on purpose, so the mistake is caught at boot.

#include <cstddef>
#include <cstdint>

extern const uint8_t g_kws_model_data[];
extern const size_t g_kws_model_len;

const uint8_t g_kws_model_data[] = { 0x00 };
const size_t g_kws_model_len = sizeof(g_kws_model_data);
