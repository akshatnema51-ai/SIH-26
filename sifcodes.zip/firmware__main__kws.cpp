#include "kws.h"
#include "esp_log.h"
#include "esp_timer.h"
#include <cmath>

// ESP-NN accelerated kernels are registered automatically when the
// TFLite-Micro component is built with CONFIG_NN_OPTIMIZATIONS enabled
// for the ESP32-S3 (see firmware/CMakeLists.txt / sdkconfig).

namespace vyom {

static const char* TAG = "kws";

// ---------------- TemporalSmoother ----------------

void TemporalSmoother::Push(float wakeword_prob) {
    history_[idx_] = wakeword_prob;
    idx_ = (idx_ + 1) % kSmoothingWindow;
    if (filled_ < kSmoothingWindow) filled_++;
}

float TemporalSmoother::SmoothedConfidence() const {
    if (filled_ == 0) return 0.0f;
    float sum = 0.0f;
    for (int i = 0; i < filled_; ++i) sum += history_[i];
    return sum / filled_;
}

void TemporalSmoother::Reset() {
    history_.fill(0.0f);
    idx_ = 0;
    filled_ = 0;
}

// ---------------- KwsEngine ----------------

KwsEngine::KwsEngine() {}

bool KwsEngine::Init(const uint8_t* model_data, size_t model_len) {
    model_ = tflite::GetModel(model_data);
    if (model_->version() != TFLITE_SCHEMA_VERSION) {
        ESP_LOGE(TAG, "Model schema version mismatch: %lu vs %d",
                 (unsigned long)model_->version(), TFLITE_SCHEMA_VERSION);
        return false;
    }

    // Register only the ops required by the DS-CNN / compact CNN KWS model
    // to keep flash/RAM footprint minimal.
    resolver_.AddConv2D();
    resolver_.AddDepthwiseConv2D();
    resolver_.AddFullyConnected();
    resolver_.AddSoftmax();
    resolver_.AddReshape();
    resolver_.AddAveragePool2D();
    resolver_.AddRelu();
    resolver_.AddQuantize();

    static tflite::MicroInterpreter static_interpreter(
        model_, resolver_, tensor_arena_, kTensorArenaSize, &error_reporter_);
    interpreter_ = &static_interpreter;

    TfLiteStatus alloc_status = interpreter_->AllocateTensors();
    if (alloc_status != kTfLiteOk) {
        ESP_LOGE(TAG, "AllocateTensors() failed");
        return false;
    }

    input_ = interpreter_->input(0);
    output_ = interpreter_->output(0);

    ESP_LOGI(TAG, "KWS model loaded. Arena used: %u bytes",
             (unsigned)interpreter_->arena_used_bytes());
    return true;
}

void KwsEngine::QuantizeInput(const MfccExtractor& mfcc) {
    // Input tensor shape: [1, kNumFramesWindow, kNumMfcc, 1], INT8.
    const float scale = input_->params.scale;
    const int32_t zero_point = input_->params.zero_point;
    const MfccFrame* window = mfcc.Window();

    int8_t* in_data = input_->data.int8;
    for (int f = 0; f < kNumFramesWindow; ++f) {
        for (int c = 0; c < kNumMfcc; ++c) {
            float v = window[f][c];
            int32_t q = (int32_t)lroundf(v / scale) + zero_point;
            if (q < -128) q = -128;
            if (q > 127) q = 127;
            in_data[f * kNumMfcc + c] = (int8_t)q;
        }
    }
}

float KwsEngine::DequantizeOutput(int index) const {
    const float scale = output_->params.scale;
    const int32_t zero_point = output_->params.zero_point;
    int8_t q = output_->data.int8[index];
    return (q - zero_point) * scale;
}

KwsResult KwsEngine::Infer(const MfccExtractor& mfcc) {
    KwsResult result{};
    if (!mfcc.WindowFull()) {
        result.label = KwsLabel::kSilence;
        result.confidence = 0.0f;
        result.smoothed_confidence = smoother_.SmoothedConfidence();
        result.triggered = false;
        return result;
    }

    int64_t t0 = esp_timer_get_time();
    QuantizeInput(mfcc);

    TfLiteStatus invoke_status = interpreter_->Invoke();
    if (invoke_status != kTfLiteOk) {
        ESP_LOGW(TAG, "Invoke failed");
        result.label = KwsLabel::kSilence;
        return result;
    }
    last_infer_us_ = (uint32_t)(esp_timer_get_time() - t0);

    float wakeword_conf = DequantizeOutput((int)KwsLabel::kWakeWord);
    float best_conf = -1.0f;
    KwsLabel best_label = KwsLabel::kSilence;
    for (int i = 0; i < (int)KwsLabel::kNumLabels; ++i) {
        float c = DequantizeOutput(i);
        if (c > best_conf) { best_conf = c; best_label = (KwsLabel)i; }
    }

    smoother_.Push(wakeword_conf);
    float smoothed = smoother_.SmoothedConfidence();

    result.label = best_label;
    result.confidence = wakeword_conf;
    result.smoothed_confidence = smoothed;
    result.triggered = (smoothed >= kFireThreshold);
    return result;
}

} // namespace vyom
