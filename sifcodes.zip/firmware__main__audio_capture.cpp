#include "audio_capture.h"
#include <cstring>
#include "esp_log.h"

namespace vyom {

static const char* TAG = "audio_capture";

// ---------------- AudioRingBuffer ----------------

AudioRingBuffer::AudioRingBuffer(size_t capacity_frames)
    : capacity_(capacity_frames) {
    buf_ = new int16_t[capacity_];
    mutex_ = xSemaphoreCreateMutex();
}

AudioRingBuffer::~AudioRingBuffer() {
    delete[] buf_;
    vSemaphoreDelete(mutex_);
}

void AudioRingBuffer::Write(const int16_t* samples, size_t count) {
    xSemaphoreTake(mutex_, portMAX_DELAY);
    for (size_t i = 0; i < count; ++i) {
        buf_[write_idx_] = samples[i];
        write_idx_ = (write_idx_ + 1) % capacity_;
        if (count_ < capacity_) {
            count_++;
        } else {
            // buffer full: consumer read pointer must advance too
            read_idx_ = (read_idx_ + 1) % capacity_;
        }
    }
    xSemaphoreGive(mutex_);
}

size_t AudioRingBuffer::Read(int16_t* out, size_t count) {
    xSemaphoreTake(mutex_, portMAX_DELAY);
    size_t n = count < count_ ? count : count_;
    for (size_t i = 0; i < n; ++i) {
        out[i] = buf_[read_idx_];
        read_idx_ = (read_idx_ + 1) % capacity_;
    }
    count_ -= n;
    xSemaphoreGive(mutex_);
    return n;
}

size_t AudioRingBuffer::PeekLatest(int16_t* out, size_t count) const {
    xSemaphoreTake(mutex_, portMAX_DELAY);
    size_t n = count < count_ ? count : count_;
    size_t start = (write_idx_ + capacity_ - n) % capacity_;
    for (size_t i = 0; i < n; ++i) {
        out[i] = buf_[(start + i) % capacity_];
    }
    xSemaphoreGive(mutex_);
    return n;
}

size_t AudioRingBuffer::Available() const {
    xSemaphoreTake(mutex_, portMAX_DELAY);
    size_t c = count_;
    xSemaphoreGive(mutex_);
    return c;
}

// ---------------- AudioCapture ----------------

AudioCapture::AudioCapture(AudioRingBuffer& ring_buffer, const I2SPinConfig& pins)
    : ring_(ring_buffer), pins_(pins) {}

esp_err_t AudioCapture::Init() {
    i2s_chan_config_t chan_cfg = I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_0, I2S_ROLE_MASTER);
    chan_cfg.dma_desc_num = kI2SDmaBufCount;
    chan_cfg.dma_frame_num = kI2SDmaFrameLen;

    esp_err_t err = i2s_new_channel(&chan_cfg, nullptr, &rx_handle_);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "i2s_new_channel failed: %d", err);
        return err;
    }

    i2s_std_config_t std_cfg = {
        .clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(kSampleRateHz),
        .slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(
            (i2s_data_bit_width_t)kI2SBitsPerSample, I2S_SLOT_MODE_STEREO),
        .gpio_cfg = {
            .mclk = I2S_GPIO_UNUSED,
            .bclk = (gpio_num_t)pins_.bck_io_num,
            .ws   = (gpio_num_t)pins_.ws_io_num,
            .dout = I2S_GPIO_UNUSED,
            .din  = (gpio_num_t)pins_.data_in_num,
            .invert_flags = { false, false, false },
        },
    };

    err = i2s_channel_init_std_mode(rx_handle_, &std_cfg);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "i2s_channel_init_std_mode failed: %d", err);
        return err;
    }

    err = i2s_channel_enable(rx_handle_);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "i2s_channel_enable failed: %d", err);
        return err;
    }

    ESP_LOGI(TAG, "I2S initialized: %lu Hz, %lu-bit, stereo",
             (unsigned long)kSampleRateHz, (unsigned long)kI2SBitsPerSample);
    return ESP_OK;
}

esp_err_t AudioCapture::CaptureOnce() {
    size_t bytes_read = 0;
    esp_err_t err = i2s_channel_read(rx_handle_, dma_raw_, sizeof(dma_raw_),
                                      &bytes_read, portMAX_DELAY);
    if (err != ESP_OK) {
        ESP_LOGW(TAG, "i2s_channel_read error: %d", err);
        return err;
    }

    size_t frames = bytes_read / (sizeof(int32_t) * 2); // stereo frames
    // Left channel = INMP441 #0 (L/R pin -> GND), Right = INMP441 #1 (L/R -> VDD).
    // Downmix strategy: use mic0 (left) as the primary KWS channel. A simple
    // average of both channels is used to reduce single-mic self-noise while
    // still behaving as a single virtual mic for the MFCC pipeline.
    for (size_t i = 0; i < frames; ++i) {
        int32_t left  = dma_raw_[2 * i]     >> 14; // scale 32-bit slot (24-bit data) to ~16-bit
        int32_t right = dma_raw_[2 * i + 1] >> 14;
        int32_t mixed = (left + right) / 2;
        if (mixed > INT16_MAX) mixed = INT16_MAX;
        if (mixed < INT16_MIN) mixed = INT16_MIN;
        mono_scratch_[i] = (int16_t)mixed;
    }

    ring_.Write(mono_scratch_, frames);
    total_frames_ += frames;
    return ESP_OK;
}

} // namespace vyom
