#pragma once
// Wake-word detection orchestration: ties the ring buffer, MFCC extractor
// and KWS engine together, and manages the pre-trigger audio buffer that
// is sent to the cloud ASR alongside the streamed command audio.

#include <cstdint>
#include <functional>
#include "audio_capture.h"
#include "mfcc.h"
#include "kws.h"

namespace vyom {

// How much audio (ms) captured *before* the wake-word fires is preserved
// and prepended to the stream sent to the ASR backend, so the very start
// of the user's command is never clipped.
constexpr uint32_t kPreTriggerMs = 500;
constexpr size_t kPreTriggerSamples = kSampleRateHz * kPreTriggerMs / 1000;

using WakeWordCallback = std::function<void(const int16_t* pretrigger_audio,
                                             size_t pretrigger_len,
                                             float confidence)>;

class WakeWordDetector {
public:
    WakeWordDetector(AudioRingBuffer& ring, KwsEngine& kws);

    void SetCallback(WakeWordCallback cb) { callback_ = std::move(cb); }

    // Call repeatedly from the KWS FreeRTOS task. Pulls kFrameStepSamples
    // of new audio from the ring buffer, feeds MFCC + KWS, and fires the
    // callback with the pre-trigger snapshot when confidence crosses
    // threshold. Returns true if a detection fired this call.
    bool Process();

    // After a wake word fires, calling this suppresses immediate
    // re-triggering while the command is being streamed/ASR'd.
    void SetSuppressed(bool suppressed) { suppressed_ = suppressed; }

    const KwsResult& LastResult() const { return last_result_; }

private:
    AudioRingBuffer& ring_;
    KwsEngine& kws_;
    MfccExtractor mfcc_;
    WakeWordCallback callback_;
    KwsResult last_result_{};
    bool suppressed_ = false;

    int16_t hop_buf_[kFrameStepSamples];
    int16_t pretrigger_buf_[kPreTriggerSamples];
};

} // namespace vyom
