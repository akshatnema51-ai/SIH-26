"""
Data augmentation for KWS training: time-shift, noise mixing, volume
scaling, and simple SpecAugment-style masking applied to MFCC features.
Improves robustness against real-world microphone conditions and reduces
false triggers.
"""
from __future__ import annotations

import numpy as np


def time_shift(clip: np.ndarray, max_shift: int, rng: np.random.Generator) -> np.ndarray:
    """Randomly rolls the clip left/right by up to max_shift samples,
    zero-filling the wrapped region."""
    shift = int(rng.integers(-max_shift, max_shift + 1))
    shifted = np.roll(clip, shift)
    if shift > 0:
        shifted[:shift] = 0
    elif shift < 0:
        shifted[shift:] = 0
    return shifted


def mix_background_noise(clip: np.ndarray, noise: np.ndarray, snr_db: float,
                          rng: np.random.Generator) -> np.ndarray:
    """Mixes `noise` into `clip` at the given signal-to-noise ratio (dB)."""
    if len(noise) < len(clip):
        reps = int(np.ceil(len(clip) / len(noise)))
        noise = np.tile(noise, reps)
    start = int(rng.integers(0, len(noise) - len(clip) + 1))
    noise_seg = noise[start:start + len(clip)].astype(np.float32)

    clip_f = clip.astype(np.float32)
    clip_power = np.mean(clip_f ** 2) + 1e-8
    noise_power = np.mean(noise_seg ** 2) + 1e-8

    target_noise_power = clip_power / (10 ** (snr_db / 10))
    noise_scaled = noise_seg * np.sqrt(target_noise_power / noise_power)

    mixed = clip_f + noise_scaled
    mixed = np.clip(mixed, -32768, 32767)
    return mixed.astype(np.int16)


def volume_scale(clip: np.ndarray, gain_range: tuple[float, float],
                  rng: np.random.Generator) -> np.ndarray:
    gain = rng.uniform(*gain_range)
    scaled = clip.astype(np.float32) * gain
    return np.clip(scaled, -32768, 32767).astype(np.int16)


def spec_augment(mfcc: np.ndarray, freq_mask_width: int, time_mask_width: int,
                  rng: np.random.Generator) -> np.ndarray:
    """
    Applies frequency and time masking directly on an MFCC feature matrix
    [num_frames, num_coeffs], matching the shape fed to the DS-CNN model.
    """
    augmented = mfcc.copy()
    num_frames, num_coeffs = augmented.shape

    if freq_mask_width > 0 and num_coeffs > freq_mask_width:
        f0 = int(rng.integers(0, num_coeffs - freq_mask_width))
        augmented[:, f0:f0 + freq_mask_width] = 0.0

    if time_mask_width > 0 and num_frames > time_mask_width:
        t0 = int(rng.integers(0, num_frames - time_mask_width))
        augmented[t0:t0 + time_mask_width, :] = 0.0

    return augmented


def augment_clip(clip: np.ndarray, background_noises: list[np.ndarray],
                  rng: np.random.Generator,
                  max_shift_samples: int = 1600,
                  snr_choices: tuple[float, ...] = (5.0, 10.0, 15.0, 20.0),
                  gain_range: tuple[float, float] = (0.7, 1.3),
                  noise_prob: float = 0.7) -> np.ndarray:
    """Applies a randomized chain of waveform-level augmentations to one clip."""
    out = time_shift(clip, max_shift_samples, rng)
    out = volume_scale(out, gain_range, rng)
    if background_noises and rng.random() < noise_prob:
        noise = background_noises[int(rng.integers(0, len(background_noises)))]
        snr = float(rng.choice(snr_choices))
        out = mix_background_noise(out, noise, snr, rng)
    return out


def augment_batch(clips: np.ndarray, labels: np.ndarray, background_noises: list[np.ndarray],
                   seed: int = 0, multiplier: int = 1) -> tuple[np.ndarray, np.ndarray]:
    """
    Expands a dataset by generating `multiplier` augmented copies per
    original clip (in addition to the original), for use before MFCC
    extraction in train_kws.py.
    """
    rng = np.random.default_rng(seed)
    out_clips = [clips]
    out_labels = [labels]

    for _ in range(multiplier):
        augmented = np.stack([
            augment_clip(clips[i], background_noises, rng) for i in range(len(clips))
        ])
        out_clips.append(augmented)
        out_labels.append(labels.copy())

    return np.concatenate(out_clips), np.concatenate(out_labels)
