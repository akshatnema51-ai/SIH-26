"""
ASR engine abstraction.

Defines a common interface so the WebSocket server can swap between
Whisper and Vosk backends without caring about engine-specific details.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class TranscriptionResult:
    text: str
    confidence: float
    is_final: bool
    engine: str
    latency_ms: float


class AsrEngine(ABC):
    """Common interface for streaming/batch ASR backends."""

    @abstractmethod
    async def load(self) -> None:
        """Load model weights. Called once at server startup."""
        raise NotImplementedError

    @abstractmethod
    async def transcribe_pcm16(self, pcm_bytes: bytes, sample_rate: int) -> TranscriptionResult:
        """
        Transcribe a complete utterance of little-endian mono PCM16 audio.

        Args:
            pcm_bytes: raw PCM16 samples (pre-trigger + streamed command).
            sample_rate: sample rate of the provided audio (Hz).
        """
        raise NotImplementedError

    @property
    @abstractmethod
    def name(self) -> str:
        raise NotImplementedError


class AsrEngineError(Exception):
    """Raised when transcription fails or the engine is unavailable."""
