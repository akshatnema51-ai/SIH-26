"""
Whisper ASR engine (openai-whisper or faster-whisper backend).

Uses faster-whisper (CTranslate2) when available for lower latency /
lower memory use; falls back to openai-whisper otherwise.
"""
from __future__ import annotations

import asyncio
import io
import logging
import time
import wave

import numpy as np

from .base import AsrEngine, AsrEngineError, TranscriptionResult

logger = logging.getLogger("vyom.asr.whisper")


class WhisperAsrEngine(AsrEngine):
    def __init__(self, model_size: str = "base.en", device: str = "auto"):
        self.model_size = model_size
        self.device = device
        self._model = None
        self._backend = None  # "faster_whisper" | "openai_whisper"

    @property
    def name(self) -> str:
        return f"whisper:{self.model_size}"

    async def load(self) -> None:
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self._load_sync)

    def _load_sync(self) -> None:
        try:
            from faster_whisper import WhisperModel

            compute_type = "int8" if self.device != "cuda" else "float16"
            device = "cuda" if self.device == "cuda" else "cpu"
            self._model = WhisperModel(self.model_size, device=device, compute_type=compute_type)
            self._backend = "faster_whisper"
            logger.info("Loaded faster-whisper model '%s' on %s (%s)",
                        self.model_size, device, compute_type)
        except ImportError:
            import whisper

            self._model = whisper.load_model(self.model_size.replace(".en", ""))
            self._backend = "openai_whisper"
            logger.info("Loaded openai-whisper model '%s'", self.model_size)

    async def transcribe_pcm16(self, pcm_bytes: bytes, sample_rate: int) -> TranscriptionResult:
        if self._model is None:
            raise AsrEngineError("Whisper model not loaded")

        loop = asyncio.get_event_loop()
        start = time.perf_counter()
        text, confidence = await loop.run_in_executor(
            None, self._transcribe_sync, pcm_bytes, sample_rate
        )
        latency_ms = (time.perf_counter() - start) * 1000.0

        return TranscriptionResult(
            text=text.strip(),
            confidence=confidence,
            is_final=True,
            engine=self.name,
            latency_ms=latency_ms,
        )

    def _transcribe_sync(self, pcm_bytes: bytes, sample_rate: int) -> tuple[str, float]:
        audio_f32 = np.frombuffer(pcm_bytes, dtype=np.int16).astype(np.float32) / 32768.0

        if self._backend == "faster_whisper":
            segments, info = self._model.transcribe(audio_f32, language="en", beam_size=1)
            text_parts = []
            confidences = []
            for seg in segments:
                text_parts.append(seg.text)
                if seg.avg_logprob is not None:
                    confidences.append(np.exp(seg.avg_logprob))
            text = " ".join(text_parts)
            confidence = float(np.mean(confidences)) if confidences else 0.0
            return text, confidence

        # openai-whisper fallback expects a temp wav file / float32 array directly.
        result = self._model.transcribe(audio_f32, language="en")
        return result.get("text", ""), 0.0

    @staticmethod
    def pcm_to_wav_bytes(pcm_bytes: bytes, sample_rate: int) -> bytes:
        buf = io.BytesIO()
        with wave.open(buf, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(sample_rate)
            wf.writeframes(pcm_bytes)
        return buf.getvalue()
