#pragma once
// Persistent WebSocket client. Connects once at boot and stays open, so
// there is no per-utterance connection-setup delay after a wake word is
// detected (see deck: "Persistent Socket - No connection setup after
// wake-word detection").

#include <cstdint>
#include <cstddef>
#include <string>
#include "esp_websocket_client.h"
#include "esp_err.h"

namespace vyom {

struct WsConfig {
    std::string uri = "ws://vyom-server.local:8000/ws/audio";
    int reconnect_timeout_ms = 3000;
    int network_timeout_ms = 5000;
};

enum class WsState {
    kDisconnected,
    kConnecting,
    kConnected,
    kError,
};

class WebSocketClient {
public:
    explicit WebSocketClient(const WsConfig& config = WsConfig());
    ~WebSocketClient();

    esp_err_t Init();
    esp_err_t Start();
    void Stop();

    WsState State() const { return state_; }
    bool IsConnected() const { return state_ == WsState::kConnected; }

    // Sends a binary PCM16 audio chunk (pre-trigger + streamed command
    // audio) as a binary WebSocket frame.
    esp_err_t SendAudioChunk(const int16_t* samples, size_t count);

    // Sends a small JSON control message, e.g. {"event":"utterance_start"}
    // or {"event":"utterance_end"} to bracket a streamed command.
    esp_err_t SendControl(const char* json_msg);

    // Reconnection / health metrics
    uint32_t ReconnectCount() const { return reconnect_count_; }

private:
    static void EventHandler(void* handler_args, esp_event_base_t base,
                              int32_t event_id, void* event_data);
    void OnEvent(int32_t event_id, void* event_data);

    WsConfig config_;
    esp_websocket_client_handle_t client_ = nullptr;
    WsState state_ = WsState::kDisconnected;
    uint32_t reconnect_count_ = 0;
};

} // namespace vyom
