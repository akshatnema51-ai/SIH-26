#pragma once
// Real-time monitoring: RAM, CPU, latency, and false-trigger metrics,
// reported over Serial and (optionally) an SSD1306 OLED.

#include <cstdint>
#include <cstddef>

namespace vyom {

struct SystemMetrics {
    uint32_t free_heap_bytes;
    uint32_t min_free_heap_bytes;
    float cpu_usage_percent;        // idle-task-derived estimate
    uint32_t last_kws_latency_us;   // last TFLite Invoke() duration
    uint32_t avg_kws_latency_us;
    uint32_t wakeword_triggers;
    uint32_t false_triggers;        // triggers rejected/cancelled by server
    uint32_t ws_reconnects;
    uint64_t uptime_ms;
};

class MetricsMonitor {
public:
    MetricsMonitor();

    void RecordInferenceLatency(uint32_t micros);
    void RecordTrigger() { metrics_.wakeword_triggers++; }
    void RecordFalseTrigger() { metrics_.false_triggers++; }
    void RecordWsReconnect(uint32_t total_reconnects) {
        metrics_.ws_reconnects = total_reconnects;
    }

    // Refreshes heap/CPU snapshot fields. Call periodically (e.g. 1 Hz)
    // from a low-priority FreeRTOS task.
    void Sample();

    const SystemMetrics& Get() const { return metrics_; }

    // Prints a one-line summary to the serial console.
    void LogToSerial() const;

    // Renders a compact status screen to an SSD1306 OLED over I2C, if
    // present. No-op (and safe) if the display was not detected at Init().
    void InitDisplay();
    void RenderToDisplay() const;

private:
    SystemMetrics metrics_{};
    uint64_t latency_sum_us_ = 0;
    uint32_t latency_samples_ = 0;
    bool display_present_ = false;
};

} // namespace vyom
