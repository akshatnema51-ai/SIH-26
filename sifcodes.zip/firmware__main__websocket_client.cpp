#include "websocket_client.h"
#include "esp_log.h"
#include <cstring>

namespace vyom {

static const char* TAG = "ws_client";

WebSocketClient::WebSocketClient(const WsConfig& config) : config_(config) {}

WebSocketClient::~WebSocketClient() {
    Stop();
}

esp_err_t WebSocketClient::Init() {
    esp_websocket_client_config_t ws_cfg = {};
    ws_cfg.uri = config_.uri.c_str();
    ws_cfg.reconnect_timeout_ms = config_.reconnect_timeout_ms;
    ws_cfg.network_timeout_ms = config_.network_timeout_ms;
    ws_cfg.disable_auto_reconnect = false; // keep the socket persistent

    client_ = esp_websocket_client_init(&ws_cfg);
    if (!client_) {
        ESP_LOGE(TAG, "Failed to init websocket client");
        return ESP_FAIL;
    }

    esp_websocket_register_events(client_, WEBSOCKET_EVENT_ANY, EventHandler, this);
    return ESP_OK;
}

esp_err_t WebSocketClient::Start() {
    state_ = WsState::kConnecting;
    return esp_websocket_client_start(client_);
}

void WebSocketClient::Stop() {
    if (client_) {
        esp_websocket_client_stop(client_);
        esp_websocket_client_destroy(client_);
        client_ = nullptr;
    }
    state_ = WsState::kDisconnected;
}

esp_err_t WebSocketClient::SendAudioChunk(const int16_t* samples, size_t count) {
    if (!IsConnected()) return ESP_ERR_INVALID_STATE;
    int len = esp_websocket_client_send_bin(
        client_, reinterpret_cast<const char*>(samples),
        count * sizeof(int16_t), pdMS_TO_TICKS(config_.network_timeout_ms));
    return len >= 0 ? ESP_OK : ESP_FAIL;
}

esp_err_t WebSocketClient::SendControl(const char* json_msg) {
    if (!IsConnected()) return ESP_ERR_INVALID_STATE;
    int len = esp_websocket_client_send_text(
        client_, json_msg, strlen(json_msg),
        pdMS_TO_TICKS(config_.network_timeout_ms));
    return len >= 0 ? ESP_OK : ESP_FAIL;
}

void WebSocketClient::EventHandler(void* handler_args, esp_event_base_t base,
                                    int32_t event_id, void* event_data) {
    auto* self = static_cast<WebSocketClient*>(handler_args);
    self->OnEvent(event_id, event_data);
}

void WebSocketClient::OnEvent(int32_t event_id, void* event_data) {
    switch (event_id) {
        case WEBSOCKET_EVENT_CONNECTED:
            ESP_LOGI(TAG, "WebSocket connected");
            state_ = WsState::kConnected;
            break;
        case WEBSOCKET_EVENT_DISCONNECTED:
            ESP_LOGW(TAG, "WebSocket disconnected, will auto-reconnect");
            state_ = WsState::kDisconnected;
            reconnect_count_++;
            break;
        case WEBSOCKET_EVENT_ERROR:
            ESP_LOGE(TAG, "WebSocket error");
            state_ = WsState::kError;
            break;
        case WEBSOCKET_EVENT_DATA: {
            auto* data = static_cast<esp_websocket_event_data_t*>(event_data);
            if (data->op_code == 0x1 /* text */) {
                ESP_LOGI(TAG, "Server message: %.*s", data->data_len, data->data_ptr);
            }
            break;
        }
        default:
            break;
    }
}

} // namespace vyom
