"""
VYOM-EDGE Backend Configuration
Python / FastAPI

Centralized settings for the WebSocket server and ASR engine selection.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from enum import Enum


class AsrEngineType(str, Enum):
    WHISPER = "whisper"
    VOSK = "vosk"


@dataclass
class Settings:
    # --- Server ---
    host: str = os.getenv("VYOM_HOST", "0.0.0.0")
    port: int = int(os.getenv("VYOM_PORT", "8000"))
    ws_path: str = os.getenv("VYOM_WS_PATH", "/ws/audio")

    # --- Audio ---
    sample_rate_hz: int = 16000
    sample_width_bytes: int = 2  # int16 PCM
    channels: int = 1

    # --- ASR engine selection ---
    asr_engine: AsrEngineType = AsrEngineType(os.getenv("VYOM_ASR_ENGINE", "whisper"))
    whisper_model_size: str = os.getenv("VYOM_WHISPER_MODEL", "base.en")
    vosk_model_path: str = os.getenv("VYOM_VOSK_MODEL_PATH", "models/vosk-model-small-en-us-0.15")

    # --- Utterance handling ---
    utterance_silence_timeout_s: float = 1.2  # end-of-utterance heuristic
    max_utterance_duration_s: float = 12.0
    min_utterance_duration_s: float = 0.3     # shorter than this -> false trigger

    # --- Logging ---
    log_level: str = os.getenv("VYOM_LOG_LEVEL", "INFO")

    # --- Metrics / false-trigger feedback ---
    false_trigger_confidence_threshold: float = 0.5


settings = Settings()
