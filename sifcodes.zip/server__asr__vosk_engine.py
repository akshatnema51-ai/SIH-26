"""
Vosk ASR engine: lightweight, fully offline-capable recognizer, useful as
a low-latency alternative to Whisper for short command-style utterances.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time

from .base import AsrEngine, AsrEngineError, TranscriptionResult

logger = logging.getLogger("vyom.asr.vosk")


class VoskAsrEngine(AsrEngine):
    def __init__(self, model_path: str, sample_rate: int = 16000):
        self.model_path = model_path
        self.sample_rate = sample_rate
        self._model = None

    @property
    def name(self) -> str:
        return f"vosk:{os.path.basename(self.model_path)}"

    async def load(self) -> None:
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self._load_sync)

    def _load_sync(self) -> None:
        from vosk import Model

        if not os.path.isdir(self.model_path):
            raise AsrEngineError(
                f"Vosk model not found at '{self.model_path}'. Download one from "
                "https://alphacephei.com/vosk/models and extract it there."
            )
        self._model = Model(self.model_path)
        logger.info("Loaded Vosk model from %s", self.model_path)

    async def transcribe_pcm16(self, pcm_bytes: bytes, sample_rate: int) -> TranscriptionResult:
        if self._model is None:
            raise AsrEngineError("Vosk model not loaded")

        loop = asyncio.get_event_loop()
        start = time.perf_counter()
        text, confidence = await loop.run_in_executor(
            None, self._transcribe_sync, pcm_bytes, sample_rate
        )
        latency_ms = (time.perf_counter() - start) * 1000.0

        return TranscriptionResult(
            text=text.strip(),
            confidence=confidence,
            is_final=True,
            engine=self.name,
            latency_ms=latency_ms,
        )

    def _transcribe_sync(self, pcm_bytes: bytes, sample_rate: int) -> tuple[str, float]:
        from vosk import KaldiRecognizer

        recognizer = KaldiRecognizer(self._model, sample_rate)
        recognizer.SetWords(True)

        chunk_size = 4000
        for i in range(0, len(pcm_bytes), chunk_size):
            recognizer.AcceptWaveform(pcm_bytes[i:i + chunk_size])

        result = json.loads(recognizer.FinalResult())
        text = result.get("text", "")

        word_confidences = [w.get("conf", 0.0) for w in result.get("result", [])]
        confidence = sum(word_confidences) / len(word_confidences) if word_confidences else 0.0
        return text, confidence
