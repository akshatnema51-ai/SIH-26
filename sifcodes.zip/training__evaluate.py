"""
Evaluate a trained (or quantized+TFLite) KWS model: overall accuracy,
per-class precision/recall, confusion matrix, and a false-accept /
false-reject rate curve appropriate for wake-word systems.
"""
from __future__ import annotations

import argparse
import logging
from pathlib import Path

import numpy as np
import tensorflow as tf

from train_kws import prepare_features, load_split, NUM_CLASSES

logger = logging.getLogger("vyom.evaluate")

CLASS_NAMES = ["silence", "unknown", "wakeword"]
WAKEWORD_LABEL = 2


def confusion_matrix(y_true: np.ndarray, y_pred: np.ndarray, num_classes: int = NUM_CLASSES) -> np.ndarray:
    cm = np.zeros((num_classes, num_classes), dtype=np.int64)
    for t, p in zip(y_true, y_pred):
        cm[t, p] += 1
    return cm


def print_confusion_matrix(cm: np.ndarray) -> None:
    header = "        " + "".join(f"{name:>10}" for name in CLASS_NAMES)
    logger.info(header)
    for i, row in enumerate(cm):
        row_str = "".join(f"{v:>10}" for v in row)
        logger.info(f"{CLASS_NAMES[i]:>8}{row_str}")


def precision_recall(cm: np.ndarray) -> dict[str, dict[str, float]]:
    stats = {}
    for i, name in enumerate(CLASS_NAMES):
        tp = cm[i, i]
        fp = cm[:, i].sum() - tp
        fn = cm[i, :].sum() - tp
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        stats[name] = {"precision": precision, "recall": recall}
    return stats


def false_accept_reject_rates(y_true: np.ndarray, wakeword_probs: np.ndarray,
                               thresholds: np.ndarray) -> list[dict[str, float]]:
    """
    For each threshold, computes:
      - False Accept Rate (FAR): fraction of non-wakeword clips classified as wakeword
      - False Reject Rate (FRR): fraction of wakeword clips classified as non-wakeword
    """
    is_wakeword = y_true == WAKEWORD_LABEL
    results = []
    for th in thresholds:
        predicted_wakeword = wakeword_probs >= th
        far = np.mean(predicted_wakeword[~is_wakeword]) if np.any(~is_wakeword) else 0.0
        frr = np.mean(~predicted_wakeword[is_wakeword]) if np.any(is_wakeword) else 0.0
        results.append({"threshold": float(th), "far": float(far), "frr": float(frr)})
    return results


def run_keras_model(model_path: Path, features: np.ndarray) -> np.ndarray:
    model = tf.keras.models.load_model(model_path)
    return model.predict(features, verbose=0)


def run_tflite_model(model_path: Path, features: np.ndarray) -> np.ndarray:
    interpreter = tf.lite.Interpreter(model_path=str(model_path))
    interpreter.allocate_tensors()
    input_details = interpreter.get_input_details()[0]
    output_details = interpreter.get_output_details()[0]

    scale, zero_point = input_details["quantization"]
    is_quantized = input_details["dtype"] == np.int8

    probs = np.zeros((len(features), NUM_CLASSES), dtype=np.float32)
    for i, feat in enumerate(features):
        x = feat[np.newaxis, ...]
        if is_quantized:
            x = (x / scale + zero_point).astype(np.int8)
        interpreter.set_tensor(input_details["index"], x)
        interpreter.invoke()
        out = interpreter.get_tensor(output_details["index"])[0]
        if output_details["dtype"] == np.int8:
            out_scale, out_zp = output_details["quantization"]
            out = (out.astype(np.float32) - out_zp) * out_scale
        probs[i] = out
    return probs


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")
    parser = argparse.ArgumentParser(description="Evaluate VYOM-EDGE KWS model")
    parser.add_argument("--data-dir", type=Path, default=Path("data/prepared"))
    parser.add_argument("--model", type=Path, required=True,
                         help="Path to .keras model or .tflite model")
    parser.add_argument("--split", default="test", choices=["val", "test"])
    args = parser.parse_args()

    x_raw, y = load_split(args.data_dir, args.split)
    features, y = prepare_features(x_raw, y)

    if args.model.suffix == ".tflite":
        probs = run_tflite_model(args.model, features)
    else:
        probs = run_keras_model(args.model, features)

    y_pred = np.argmax(probs, axis=1)

    accuracy = float(np.mean(y_pred == y))
    logger.info("Overall accuracy: %.4f", accuracy)

    cm = confusion_matrix(y, y_pred)
    print_confusion_matrix(cm)

    stats = precision_recall(cm)
    for name, s in stats.items():
        logger.info("%-10s precision=%.4f recall=%.4f", name, s["precision"], s["recall"])

    thresholds = np.linspace(0.1, 0.99, 15)
    far_frr = false_accept_reject_rates(y, probs[:, WAKEWORD_LABEL], thresholds)
    logger.info("Threshold sweep (FAR = false accept rate, FRR = false reject rate):")
    for row in far_frr:
        logger.info("  th=%.2f  FAR=%.4f  FRR=%.4f", row["threshold"], row["far"], row["frr"])


if __name__ == "__main__":
    main()
