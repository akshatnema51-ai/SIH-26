# VYOM-EDGE

**Low Latency and Efficient Voice Activator for Edge Devices**
Smart India Hackathon 2026 — Problem Statement SIH26172 — Team **Caffeine Codes**

A featherweight edge voice activator that continuously listens on an ESP32-S3,
detects a single custom wake word entirely on-device using an INT8-quantized
keyword-spotting (KWS) model, then opens a **persistent** WebSocket connection
to a cloud ASR backend (Whisper or Vosk) to transcribe the command that follows.

## Programming Language Policy

| Layer | Language | Notes |
|---|---|---|
| ESP32-S3 firmware | **C++ / ESP-IDF** | `.cpp` / `.h` only |
| KWS inference on-device | **C++** | TensorFlow Lite for Microcontrollers + ESP-NN |
| Backend / server | **Python** | FastAPI + WebSocket |
| ASR | **Python** | Whisper / Vosk |
| Model training & quantization | **Python** | TensorFlow |

**C# is never used anywhere in this project** — no .NET, ASP.NET, Blazor, or
Unity C# scripts.

## Architecture

```
 ESP32-S3 (C++/ESP-IDF)                          Server (Python/FastAPI)
 ┌─────────────────────────┐   WebSocket (WS)    ┌─────────────────────────┐
 │ Dual INMP441 I2S mics    │◄───────────────────►│ WebSocket server         │
 │  -> ring buffer          │  binary PCM16 +     │  -> utterance bracketing │
 │  -> incremental MFCC     │  JSON control frames│  -> ASR dispatch         │
 │  -> INT8 DS-CNN KWS      │                     │     (Whisper / Vosk)     │
 │     (TFLite Micro+ESP-NN)│                     │  -> false-trigger filter │
 │  -> temporal smoothing   │                     └─────────────────────────┘
 │  -> pre-trigger buffer   │
 │  -> RAM/CPU/latency      │
 │     metrics (serial/OLED)│
 └─────────────────────────┘
```

## Why VYOM-EDGE is different

- **Temporal smoothing** — requires several consecutive high-confidence frames
  before firing, suppressing single-frame false triggers.
- **Persistent socket** — the WebSocket connects once at boot; there is no
  connection-setup delay after a wake word is detected.
- **Incremental features** — MFCC extraction only computes the new,
  non-overlapping portion of each analysis window per hop, keeping idle CPU low.
- **Pre-trigger buffer** — ~500ms of audio immediately preceding detection is
  preserved and sent first, so the start of the command is never clipped.
- **Real-time monitoring** — RAM, CPU, inference latency, and false-trigger
  counters are logged to serial (and optionally an OLED) continuously.

## Project layout

```
vyom-edge/
├── firmware/     # C++ / ESP-IDF firmware for the ESP32-S3
├── server/       # Python FastAPI backend + WebSocket server + ASR engines
├── training/     # Python KWS dataset prep, augmentation, training, quantization
├── tests/        # pytest server tests + benchmarking scripts
└── README.md
```

## Getting started

### 1. Train the KWS model
```bash
cd training
pip install -r requirements.txt
python dataset.py --root /path/to/raw_dataset --out data/prepared
python train_kws.py --data-dir data/prepared --raw-dataset-root /path/to/raw_dataset
python quantize.py --model models/kws_float.keras --data-dir data/prepared
python evaluate.py --data-dir data/prepared --model models/kws_int8.tflite
python convert_tflite.py --model models/kws_int8.tflite --out ../firmware/main/kws_model_data.cpp
```

### 2. Run the backend
```bash
cd server
pip install -r requirements.txt
export VYOM_ASR_ENGINE=whisper   # or vosk
uvicorn main:app --host 0.0.0.0 --port 8000
```

### 3. Flash the firmware
```bash
cd firmware
idf.py set-target esp32s3
idf.py menuconfig   # set Wi-Fi credentials, WS server URI
idf.py build flash monitor
```

### 4. Run tests / benchmarks
```bash
cd tests
pytest test_server.py
python benchmark.py asr --engine whisper --runs 5
python benchmark.py kws --model ../training/models/kws_int8.tflite
```

## Design targets (from the SIH proposal)

- RAM: **< 256 KB**
- Idle CPU: **< 10%**
- Wake word detected fully offline; persistent connection removes
  connection-establishment delay from the command path.

## References

- Radford et al., *Robust Speech Recognition via Large-Scale Weak Supervision* (2022)
- Zhang et al., *Hello Edge: Keyword Spotting on Microcontrollers* (2017)
- Warden, *Speech Commands: A Dataset for Limited-Vocabulary Speech Recognition* (2018)
- Rybakov et al., *Streaming keyword spotting on mobile devices* (2020)
- Sørensen et al., *A depthwise separable convolutional neural network for keyword spotting on an embedded system* (2020)
- Espressif Systems, *ESP-NN — Optimized Neural Network Kernels for ESP32-S3*
