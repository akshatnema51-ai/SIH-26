#include "metrics.h"
#include "esp_log.h"
#include "esp_heap_caps.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <cstdio>

namespace vyom {

static const char* TAG = "metrics";

MetricsMonitor::MetricsMonitor() {}

void MetricsMonitor::RecordInferenceLatency(uint32_t micros) {
    metrics_.last_kws_latency_us = micros;
    latency_sum_us_ += micros;
    latency_samples_++;
    metrics_.avg_kws_latency_us = (uint32_t)(latency_sum_us_ / latency_samples_);
}

void MetricsMonitor::Sample() {
    metrics_.free_heap_bytes = heap_caps_get_free_size(MALLOC_CAP_8BIT);
    metrics_.min_free_heap_bytes = heap_caps_get_minimum_free_size(MALLOC_CAP_8BIT);
    metrics_.uptime_ms = esp_timer_get_time() / 1000;

    // Approximate CPU usage via the FreeRTOS idle-task runtime counters
    // (requires CONFIG_FREERTOS_GENERATE_RUN_TIME_STATS in sdkconfig).
    static char stats_buf[1024];
    vTaskGetRunTimeStats(stats_buf);
    // Parsing omitted for brevity in this scaffold: a production build
    // should sum "IDLE" ticks vs total ticks from stats_buf. Placeholder
    // keeps the field populated with a safe default until wired up.
    (void)stats_buf;
}

void MetricsMonitor::LogToSerial() const {
    ESP_LOGI(TAG,
        "heap=%lu/minheap=%lu cpu=%.1f%% kws_lat=%luus avg=%luus "
        "triggers=%lu false=%lu ws_reconnects=%lu uptime=%llums",
        (unsigned long)metrics_.free_heap_bytes,
        (unsigned long)metrics_.min_free_heap_bytes,
        metrics_.cpu_usage_percent,
        (unsigned long)metrics_.last_kws_latency_us,
        (unsigned long)metrics_.avg_kws_latency_us,
        (unsigned long)metrics_.wakeword_triggers,
        (unsigned long)metrics_.false_triggers,
        (unsigned long)metrics_.ws_reconnects,
        (unsigned long long)metrics_.uptime_ms);
}

void MetricsMonitor::InitDisplay() {
    // Placeholder: probe I2C bus for an SSD1306 at 0x3C. Set
    // display_present_ = true on success. Left as an integration point
    // for the specific OLED driver component used in the build
    // (e.g. esp_lcd + ssd1306, or a lightweight u8g2 port).
    display_present_ = false;
    ESP_LOGI(TAG, "OLED display %s", display_present_ ? "detected" : "not detected, serial-only");
}

void MetricsMonitor::RenderToDisplay() const {
    if (!display_present_) return;
    char line1[32], line2[32];
    snprintf(line1, sizeof(line1), "RAM:%lu KB", (unsigned long)(metrics_.free_heap_bytes / 1024));
    snprintf(line2, sizeof(line2), "KWS:%luus T:%lu",
             (unsigned long)metrics_.last_kws_latency_us,
             (unsigned long)metrics_.wakeword_triggers);
    // Actual pixel drawing calls go here once the OLED driver is wired in.
}

} // namespace vyom
