"""
WebSocket server: accepts the ESP32-S3's persistent connection, receives
binary PCM16 audio chunks bracketed by JSON control frames
({"event":"utterance_start"/"utterance_end"}), and dispatches complete
utterances to the configured ASR engine.
"""
from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field

from fastapi import WebSocket, WebSocketDisconnect

from asr.base import AsrEngine, AsrEngineError
from config import Settings

logger = logging.getLogger("vyom.ws")


@dataclass
class UtteranceBuffer:
    """Accumulates PCM16 bytes for a single wake-word-triggered utterance."""
    chunks: list[bytes] = field(default_factory=list)
    start_time: float = 0.0
    confidence: float = 0.0
    last_audio_time: float = 0.0

    def append(self, data: bytes) -> None:
        self.chunks.append(data)
        self.last_audio_time = time.monotonic()

    def duration_s(self, sample_rate: int) -> float:
        total_bytes = sum(len(c) for c in self.chunks)
        total_samples = total_bytes // 2  # int16
        return total_samples / sample_rate

    def as_bytes(self) -> bytes:
        return b"".join(self.chunks)

    def silence_elapsed_s(self) -> float:
        if self.last_audio_time == 0.0:
            return 0.0
        return time.monotonic() - self.last_audio_time


class ConnectionHandler:
    """
    One instance per connected ESP32-S3 device. Since the firmware keeps a
    single persistent socket open, this class's lifetime spans the whole
    device session, not just one utterance.
    """

    def __init__(self, websocket: WebSocket, asr_engine: AsrEngine, settings: Settings):
        self.ws = websocket
        self.asr = asr_engine
        self.settings = settings
        self.utterance: UtteranceBuffer | None = None
        self.device_id: str = "unknown"

    async def handle(self) -> None:
        await self.ws.accept()
        logger.info("Device connected")
        try:
            while True:
                message = await self.ws.receive()
                if "bytes" in message and message["bytes"] is not None:
                    await self._on_audio_chunk(message["bytes"])
                elif "text" in message and message["text"] is not None:
                    await self._on_control_message(message["text"])
        except WebSocketDisconnect:
            logger.info("Device disconnected (%s)", self.device_id)

    async def _on_control_message(self, raw: str) -> None:
        try:
            msg = json.loads(raw)
        except json.JSONDecodeError:
            logger.warning("Malformed control message: %s", raw)
            return

        event = msg.get("event")
        if event == "utterance_start":
            self.utterance = UtteranceBuffer(
                start_time=time.monotonic(),
                confidence=float(msg.get("confidence", 0.0)),
            )
            logger.debug("Utterance started (confidence=%.3f)", self.utterance.confidence)

        elif event == "utterance_end":
            await self._finalize_utterance()

        elif event == "hello":
            self.device_id = msg.get("device_id", self.device_id)
            logger.info("Device identified as %s", self.device_id)

    async def _on_audio_chunk(self, data: bytes) -> None:
        if self.utterance is None:
            # Wake-word pre-trigger audio arrives as the first binary frame
            # right after utterance_start; if a client sends audio before
            # any control frame (e.g. reconnect edge case), start implicitly.
            self.utterance = UtteranceBuffer(start_time=time.monotonic())
        self.utterance.append(data)

        # Server-side end-of-utterance heuristic: close the utterance after
        # a period of silence rather than waiting indefinitely on the
        # device to send utterance_end (keeps behavior robust to firmware
        # bugs / packet loss).
        if self.utterance.duration_s(self.settings.sample_rate_hz) >= self.settings.max_utterance_duration_s:
            await self._finalize_utterance()

    async def _finalize_utterance(self) -> None:
        if self.utterance is None:
            return
        utt = self.utterance
        self.utterance = None

        duration = utt.duration_s(self.settings.sample_rate_hz)
        if duration < self.settings.min_utterance_duration_s:
            logger.info("Discarding short utterance (%.2fs) as likely false trigger", duration)
            await self._send_json({
                "event": "false_trigger",
                "reason": "too_short",
                "duration_s": duration,
            })
            return

        try:
            result = await self.asr.transcribe_pcm16(utt.as_bytes(), self.settings.sample_rate_hz)
        except AsrEngineError as exc:
            logger.error("ASR error: %s", exc)
            await self._send_json({"event": "error", "message": str(exc)})
            return

        logger.info("Transcribed (%s, %.1fms): %s", result.engine, result.latency_ms, result.text)
        await self._send_json({
            "event": "transcription",
            "text": result.text,
            "confidence": result.confidence,
            "engine": result.engine,
            "latency_ms": result.latency_ms,
            "wakeword_confidence": utt.confidence,
        })

    async def _send_json(self, payload: dict) -> None:
        await self.ws.send_text(json.dumps(payload))
