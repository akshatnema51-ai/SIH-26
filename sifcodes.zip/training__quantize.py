"""
Post-training INT8 quantization of the trained Keras KWS model, using a
representative dataset (real MFCC features) for full-integer
quantization so the model runs entirely in INT8 on the ESP32-S3 via
TensorFlow Lite for Microcontrollers.
"""
from __future__ import annotations

import argparse
import logging
from pathlib import Path

import numpy as np
import tensorflow as tf

from train_kws import prepare_features, load_split

logger = logging.getLogger("vyom.quantize")


def make_representative_dataset(features: np.ndarray, num_samples: int = 300):
    indices = np.random.choice(len(features), size=min(num_samples, len(features)), replace=False)

    def representative_dataset():
        for i in indices:
            yield [features[i:i + 1].astype(np.float32)]

    return representative_dataset


def quantize_model(keras_model_path: Path, data_dir: Path, out_path: Path) -> None:
    model = tf.keras.models.load_model(keras_model_path)

    x_val, y_val = load_split(data_dir, "val")
    features, _ = prepare_features(x_val, y_val)

    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    converter.representative_dataset = make_representative_dataset(features)

    # Full-integer quantization: both weights and activations INT8, with
    # INT8 input/output tensors so the firmware's kws.cpp can feed/read
    # quantized data directly without an extra float conversion layer.
    converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
    converter.inference_input_type = tf.int8
    converter.inference_output_type = tf.int8

    tflite_model = converter.convert()

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(tflite_model)

    size_kb = len(tflite_model) / 1024
    logger.info("Quantized INT8 model saved to %s (%.1f KB)", out_path, size_kb)


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")
    parser = argparse.ArgumentParser(description="INT8-quantize the VYOM-EDGE KWS model")
    parser.add_argument("--model", type=Path, default=Path("models/kws_float.keras"))
    parser.add_argument("--data-dir", type=Path, default=Path("data/prepared"))
    parser.add_argument("--out", type=Path, default=Path("models/kws_int8.tflite"))
    args = parser.parse_args()

    quantize_model(args.model, args.data_dir, args.out)


if __name__ == "__main__":
    main()
