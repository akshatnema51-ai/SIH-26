#pragma once
// Incremental MFCC feature extraction for streaming KWS.
// Designed for low idle CPU (<10%): only computes new frames as audio
// arrives, reusing the overlapping window region instead of recomputing
// the whole feature matrix each inference tick.

#include <cstdint>
#include <cstddef>
#include <array>

namespace vyom {

constexpr int kSampleRate      = 16000;
constexpr int kFrameLenMs      = 30;
constexpr int kFrameStepMs     = 20; // 10ms overlap -> feature reuse
constexpr int kFrameLenSamples = kSampleRate * kFrameLenMs / 1000;   // 480
constexpr int kFrameStepSamples= kSampleRate * kFrameStepMs / 1000;  // 320
constexpr int kNumMelBins      = 40;
constexpr int kNumMfcc         = 10;      // coefficients kept per frame
constexpr int kFftSize         = 512;     // next pow2 >= frame len
constexpr int kNumFramesWindow = 49;      // ~1s context fed to the KWS model

// One MFCC feature frame (kNumMfcc coefficients).
using MfccFrame = std::array<float, kNumMfcc>;

class MfccExtractor {
public:
    MfccExtractor();

    // Feed a new hop's worth of raw PCM samples (kFrameStepSamples), plus
    // the trailing samples retained from the previous call to complete the
    // analysis window. Internally maintains a small history buffer, so the
    // caller just needs to keep pushing consecutive hops.
    // Returns true and writes `out_frame` when a new MFCC frame was produced.
    bool PushSamples(const int16_t* hop, size_t hop_len, MfccFrame& out_frame);

    // Access to the rolling feature window (oldest -> newest), used to feed
    // the CNN/DS-CNN input tensor [kNumFramesWindow x kNumMfcc].
    const MfccFrame* Window() const { return window_.data(); }
    int FramesInWindow() const { return frames_filled_ < kNumFramesWindow
                                       ? frames_filled_ : kNumFramesWindow; }
    bool WindowFull() const { return frames_filled_ >= kNumFramesWindow; }

    void Reset();

private:
    void ComputeFrame(const float* windowed_samples, MfccFrame& out);
    void ApplyHammingWindow(float* samples, int n) const;

    // Persistent sample history so each hop only needs kFrameStepSamples
    // of new audio to complete the next overlapping analysis window.
    std::array<int16_t, kFrameLenSamples> sample_history_{};
    int history_filled_ = 0;

    // Precomputed mel filterbank (triangular filters) and Hamming window.
    std::array<std::array<float, kFftSize / 2 + 1>, kNumMelBins> mel_filterbank_{};
    std::array<float, kFrameLenSamples> hamming_window_{};

    // Rolling circular buffer of MFCC frames for the CNN input window.
    std::array<MfccFrame, kNumFramesWindow> window_{};
    int write_pos_ = 0;
    int frames_filled_ = 0;

    void BuildMelFilterbank();
    void BuildHammingWindow();
};

} // namespace vyom
