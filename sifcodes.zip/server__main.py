"""
VYOM-EDGE Backend
FastAPI application entry point.

Run with:
    uvicorn main:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

import logging

from fastapi import FastAPI, WebSocket

from asr import create_asr_engine
from config import settings
from websocket_server import ConnectionHandler

logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger("vyom.main")

app = FastAPI(title="VYOM-EDGE Backend", version="1.0.0")

asr_engine = create_asr_engine(settings)


@app.on_event("startup")
async def on_startup() -> None:
    logger.info("Loading ASR engine: %s", settings.asr_engine.value)
    await asr_engine.load()
    logger.info("VYOM-EDGE backend ready on %s:%d%s", settings.host, settings.port, settings.ws_path)


@app.get("/health")
async def health() -> dict:
    return {
        "status": "ok",
        "asr_engine": asr_engine.name,
        "sample_rate_hz": settings.sample_rate_hz,
    }


@app.websocket(settings.ws_path)
async def websocket_endpoint(websocket: WebSocket) -> None:
    handler = ConnectionHandler(websocket, asr_engine, settings)
    await handler.handle()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host=settings.host, port=settings.port, reload=False)
